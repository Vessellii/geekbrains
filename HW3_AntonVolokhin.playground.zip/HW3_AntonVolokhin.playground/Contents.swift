import UIKit

enum doorStatus {
    case open, close
}
struct Auto {
    let color: UIColor
    var range: Double
    let year: Int
    let door: doorStatus
    let fuei: Double
    var bag:Double
    }
struct BigAuto {
    let color: UIColor
    var range: Double
    let year: Int
    let door: doorStatus
    let fuei: Double
    var kuzov: Double
    mutating func izmeneniGruza(a:Double){self.kuzov = self.kuzov - a}
}
var car1 = Auto(color: .black, range: 100, year: 2000, door: .close, fuei: 100, bag: 40)
var car2 = Auto(color: .darkGray, range: 200, year: 2000, door: .open, fuei: 40, bag: 90)
var car3 = BigAuto(color: .green, range: 0, year: 2018, door: .close, fuei: 0, kuzov: 600)

car3.izmeneniGruza(a: 36)
print(car3.kuzov)
car2.range = 600
print(car2)




    

